package project4;

/**
 * Interface class for add and remove methods.
 * @author Liman Chang, Kenneth Christian
 */
public interface Customizable {
	boolean add(Object obj);
	boolean remove(Object obj);
}
