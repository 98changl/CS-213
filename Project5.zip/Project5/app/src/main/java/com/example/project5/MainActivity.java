package com.example.project5;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

/**
 *Class contains method to starts the Main Activity along with
 * methods to start activity for 4 different Museum upon
 * button click.
 *
 * @author Liman Chang, Kenneth Christian
 */

public class MainActivity extends AppCompatActivity {

    /**
     * Method to perform application start up.
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<String> list = new ArrayList<String>();
        list.add(getString(R.string.MoMA_PS1));
        list.add(getString(R.string.New_York_Historical_Society));
        list.add(getString(R.string.Rubin_Museum));
        list.add(getString(R.string.Whitney_Museum_of_American_Art));
        ArrayAdapter<String> adapt = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);

        final ListView listView = (ListView) findViewById(R.id.listview);
        listView.setAdapter(adapt);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    //student, adult, senior, 1 == MoMA PS1
                    int price[] = {14 , 25 , 18 , 1};
                    Intent intent = new Intent(MainActivity.this , Activity2.class);
                    intent.putExtra("price" ,price);
                    startActivity(intent);

                } else if (position == 1) {
                    //student, adult, senior 2 == New-York Historical Society
                    int price[] = {13 , 22 , 17 , 2};
                    Intent intent = new Intent(MainActivity.this , Activity2.class);
                    intent.putExtra("price" , price);
                    startActivity(intent);

                } else if (position == 2) {
                    //student, adult, senior, 3 == Rubin Museum
                    int price[] = {14 , 19 , 14 , 3};
                    Intent intent = new Intent(MainActivity.this , Activity2.class);
                    intent.putExtra("price" , price);
                    startActivity(intent);

                } else if (position == 3) {
                    //student, adult, senior, 4 == Whitney Museum of American Art
                    int price[] = {18 , 25 , 18 , 4};
                    Intent intent = new Intent(MainActivity.this , Activity2.class);
                    intent.putExtra("price" , price);
                    startActivity(intent);

                }
            }
        });
    }


}