/**
This is a driver class to run project 1.
@author Kenneth Christian, Liman Chang
 */
public class RunProject1 {
	
	/**
	The main method calls the run() method in the shopping class
	@param args is not used
	 */
	public static void main(String[] args) {
		new Shopping().run();
	}
}
