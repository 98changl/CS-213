package project2;

/**
 * This is the driver class to run project 2.
 * @author Liman Chang, Kenneth Christian
 */
public class RunProject2 {

	/**
	 * The main method calls the run() method in the TransactionManager class
	 * @param args is not used
	 */
	public static void main(String[] args) {
		new TransactionManager().run();
	}

}
